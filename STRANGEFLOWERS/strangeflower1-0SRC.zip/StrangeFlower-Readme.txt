Readme file for StrangeFlower Screensaver version 1.0
------------------------------------------------------

THIS SOFTWARE IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND.
THE AUTHOR SHALL HAVE NO LIABILITY WITH RESPECT TO THE INFRINGEMENT OF COPYRIGHTS,
TRADE SECRETS OR ANY PATENTS BY THIS FILE OR ANY PART THEREOF.
IN NO EVENT WILL THE AUTHOR BE LIABLE FOR ANY LOST REVENUE OR PROFITS OR OTHER SPECIAL,
INDIRECT AND CONSEQUENTIAL DAMAGES.

The Blue Ant  www.the-blueant.com
1.0 - Initial Release

March 2006: Released on the Blue Ant site <www.the-blueant.com>
June  2005: Written in C++ the algorythm of icon256 code.
	    Overlay more representations in a flower way.
	    Adapted to be used in a savescreen by Fabio Nelli <fabio.nelli@virgilio.it>
      1995: ICON256.BAS written in QBASIC by J.C.Sprott <sprott.physics.wisc.edu> 

Copyright (c) 2005-2006 Nelli Fabio  <fabio.nelli@virgilio.it>

Used and Modified some code of Craig Wilkie <craig.wilkie@bigfoot.com>
___________________________________________________________________________

- STRANGE FLOWERS -  
Flower of strange attractors replicated as in a polar way. All randomly

____________________________________________________________________________



_____________________________________________________________________________

This distribution should contain the following files: -

    strangeflower.scr           (The main screensaver)
    strangeflower-Readme.txt    (This file)

To install the Screensaver, right click on it from Windows Explorer, and select "Install"
_______________________________________________________________________________


If anyone has any suggestions for improvements, or bug reports, please mail me at: -

    fabio.nelli@virgilio.it

Check my web site for further releases and upgrades: -

    http://www.the-blueant.com/screensaver.html

