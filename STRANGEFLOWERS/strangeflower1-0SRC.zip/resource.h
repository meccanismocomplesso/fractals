
#define IDI_ICON1                       129
#define IDC_COLOURS_EDIT                1011
#define IDC_DELAY_EDIT                  1016
#define DLG_SCRNSAVECONFIGURE           2003
#define IDC_STATIC                      -1
