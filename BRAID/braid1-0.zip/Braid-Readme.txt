Readme file for Braid Screensaver version 1.0
------------------------------------------------------

THIS SOFTWARE IS PROVIDED AS IS WITH NO WARRANTIES OF ANY KIND.
THE AUTHOR SHALL HAVE NO LIABILITY WITH RESPECT TO THE INFRINGEMENT OF COPYRIGHTS,
TRADE SECRETS OR ANY PATENTS BY THIS FILE OR ANY PART THEREOF.
IN NO EVENT WILL THE AUTHOR BE LIABLE FOR ANY LOST REVENUE OR PROFITS OR OTHER SPECIAL,
INDIRECT AND CONSEQUENTIAL DAMAGES.

The Blue Ant  www.the-blueant.com
1.0 - Initial Release

March 2006: Released on the Blue Ant site <www.the-blueant.com>
September 2005: Ported to Windows OS <fabio.nelli@virgilio.it>

Copyright (c) 2005-2006 Nelli Fabio  <fabio.nelli@virgilio.it>

Used and Modified some code of Craig Wilkie <craig.wilkie@bigfoot.com>
___________________________________________________________________________

- BRAID -  
Random braid around a circle and then changes the color in a 
rotational pattern

____________________________________________________________________________


This was ported from the Unix xscreensaver package, which is copyright 
(c) 1992, 1995, 1996, 1997, 1998 Jamie Zawinski <jwz@jwz.org>

Permission to use, copy, modify, distribute, and sell this software and its
documentation for any purpose is hereby granted without fee, provided that
the above copyright notice appear in all copies and that both that
copyright notice and this permission notice appear in supporting
documentation.  No representations are made about the suitability of this
software for any purpose.  It is provided "as is" without express or 
implied warranty.

* Copyright (c) 1995 by John Neil.
 *
 
* Permission to use, copy, modify, and distribute this software and its
 
* documentation for any purpose and without fee is hereby granted,
 
* provided that the above copyright notice appear in all copies and that
 
* both that copyright notice and this permission notice appear in
 
* supporting documentation.
 *
 
* This file is provided AS IS with no warranties of any kind.  The author
 
* shall have no liability with respect to the infringement of copyrights,
 
* trade secrets or any patents by this file or any part thereof.  In no
 
* event will the author be liable for any lost revenue or profits or
 
* other special, indirect and consequential damages.
 *
 


* Revision History:
 
* 01-Nov-2000: Allocation checks
 
* 10-May-1997: Jamie Zawinski <jwz@jwz.org> compatible with xscreensaver
 
* 01-Sep-1995: color knotted components differently, J. Neil.
 
* 29-Aug-1995: Written.  John Neil <neil@math.idbsu.edu>

_____________________________________________________________________________

This distribution should contain the following files: -

    braid.scr           (The main screensaver)
    Braid-Readme.txt    (This file)

To install the Screensaver, right click on it from Windows Explorer, and select "Install"
_______________________________________________________________________________


If anyone has any suggestions for improvements, or bug reports, please mail me at: -

    fabio.nelli@virgilio.it

Check my web site for further releases and upgrades: -

    http://www.the-blueant.com/screensaver.html

